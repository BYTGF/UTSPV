﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using PV_22_UTS_05.Properties;

namespace PV_22_UTS_05
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int tangan1 = rnd.Next(2, 12);
            int tangan2 = rnd.Next(2, 12);

            Image imgreset = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\card back black.png");
            pictureBox3.Image = imgreset;
            pictureBox4.Image = imgreset; 
            pictureBox5.Image = imgreset;
            pictureBox6.Image = imgreset;
            pictureBox7.Image = imgreset;

            label3.Text = 0.ToString();
            label4.Text = 0.ToString();
            label5.Text = 0.ToString();


            //tangan1
            if (tangan1 == 2)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\2.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if(tangan1 == 3)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\3.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 4)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\4.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 5)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\5.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 6)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\6.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 7)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\7.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 8)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\8.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 9)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\9.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }
            else if (tangan1 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox1.Image = img;
                    label1.Text = tangan1.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox1.Image = img;
                    label1.Text = tangan1.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox1.Image = img;
                    label1.Text = tangan1.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox1.Image = img;
                    label1.Text = tangan1.ToString();
                }
            }
            else if (tangan1 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox1.Image = img;
                label1.Text = tangan1.ToString();
            }

            //tangan2
            if (tangan2 == 2)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\2.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 3)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\3.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 4)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\4.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 5)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\5.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 6)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\6.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 7)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\7.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 8)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\8.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 9)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\9.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }
            else if (tangan2 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox2.Image = img;
                    label2.Text = tangan2.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox2.Image = img;
                    label2.Text = tangan2.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox2.Image = img;
                    label2.Text = tangan2.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox2.Image = img;
                    label2.Text = tangan2.ToString();
                }
            }
            else if (tangan2 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox2.Image = img;
                label2.Text = tangan2.ToString();
            }

            button1.Visible = false;
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int tangan3 = rnd.Next(2, 12);

            if (tangan3 == 2)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\2.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 3)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\3.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 4)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\4.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 5)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\5.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 6)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\6.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 7)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\7.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 8)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\8.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 9)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\9.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }
            else if (tangan3 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox3.Image = img;
                    label3.Text = tangan3.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox3.Image = img;
                    label3.Text = tangan3.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox3.Image = img;
                    label3.Text = tangan3.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox3.Image = img;
                    label3.Text = tangan3.ToString();
                }
            }
            else if (tangan3 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox3.Image = img;
                label3.Text = tangan3.ToString();
            }

            button2.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int tangan4 = rnd.Next(2, 12);

            if (tangan4 == 2)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\2.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 3)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\3.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 4)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\4.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 5)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\5.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 6)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\6.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 7)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\7.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 8)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\8.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 9)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\9.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }
            else if (tangan4 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox4.Image = img;
                    label4.Text = tangan4.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox4.Image = img;
                    label4.Text = tangan4.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox4.Image = img;
                    label4.Text = tangan4.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox4.Image = img;
                    label4.Text = tangan4.ToString();
                }
            }
            else if (tangan4 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox4.Image = img;
                label4.Text = tangan4.ToString();
            }

            button3.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int tangan5 = rnd.Next(2, 12);

            if (tangan5 == 2)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\2.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 3)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\3.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 4)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\4.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 5)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\5.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 6)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\6.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 7)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\7.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 8)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\8.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 9)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\9.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            else if (tangan5 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox5.Image = img;
                    label5.Text = tangan5.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox5.Image = img;
                    label5.Text = tangan5.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox5.Image = img;
                    label5.Text = tangan5.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox5.Image = img;
                    label5.Text = tangan5.ToString();
                }
            }
            else if (tangan5 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox5.Image = img;
                label5.Text = tangan5.ToString();
            }
            button4.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //TANGAN COMPU
            Random rnd = new Random();
            int tangan6 = rnd.Next(5, 12);
            int tangan7 = rnd.Next(10, 12);

            if (tangan6 == 5)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\5.png");
                pictureBox6.Image = img;
                label6.Text = tangan6.ToString();
            }
            else if (tangan6 == 6)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\6.png");
                pictureBox6.Image = img;
                label6.Text = tangan6.ToString();
            }
            else if (tangan6 == 7)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\7.png");
                pictureBox6.Image = img;
                label6.Text = tangan6.ToString();
            }
            else if (tangan6 == 8)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\8.png");
                pictureBox6.Image = img;
                label6.Text = tangan6.ToString();
            }
            else if (tangan6 == 9)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\9.png");
                pictureBox6.Image = img;
                label6.Text = tangan6.ToString();
            }
            else if (tangan6 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox6.Image = img;
                    label6.Text = tangan6.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox6.Image = img;
                    label6.Text = tangan6.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox6.Image = img;
                    label6.Text = tangan6.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox6.Image = img;
                    label6.Text = tangan6.ToString();
                }
            }
            else if (tangan6 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox6.Image = img;
                label6.Text = tangan6.ToString();
            }

            if (tangan7 == 10)
            {
                int sepul = rnd.Next(0, 4);
                if (sepul == 0)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\10.png");
                    pictureBox7.Image = img;
                    label7.Text = tangan7.ToString();
                }
                if (sepul == 1)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\j.png");
                    pictureBox7.Image = img;
                    label7.Text = tangan7.ToString();
                }
                if (sepul == 2)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\q.png");
                    pictureBox7.Image = img;
                    label7.Text = tangan7.ToString();
                }
                if (sepul == 3)
                {
                    Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\k.png");
                    pictureBox7.Image = img;
                    label7.Text = tangan7.ToString();
                }
            }
            else if (tangan7 == 11)
            {
                Image img = Image.FromFile(@"C:\Users\asifa\Documents\My Games\Billy\Kuliah\PV\Minggu ke - 6\PV_22_UTS_05\PV_22_UTS_05\as.png");
                pictureBox7.Image = img;
                label7.Text = tangan7.ToString();
            }


            //AKHIR
            int hand1 = int.Parse(label1.Text);
            int hand2 = int.Parse(label2.Text);
            int hand3 = int.Parse(label3.Text);
            int hand4 = int.Parse(label4.Text);
            int hand5 = int.Parse(label5.Text);
            int hand6 = int.Parse(label6.Text);
            int hand7 = int.Parse(label7.Text);

            int lasthand = hand1 + hand2 + hand3 + hand4 + hand5;
            int lasthandcomp = hand6 + hand7;


            if(lasthand == 21)
            {
                MessageBox.Show("BLACK JACKKKKK, KAMU MENANGGGG", "NOTIF");
            }
            else if (lasthand >= lasthandcomp && lasthand <= 21)
            {
                MessageBox.Show("KAMU MENANGGG", "NOTIF");
            }
            else if(lasthand < lasthandcomp){
                MessageBox.Show("KAMU KALAHHHH", "NOTIF");
            }
            
            else if (lasthand > 21)
            {
                MessageBox.Show("BUSTEDDDD, KAMU KALAHHHH", "NOTIF");
            }

            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
