﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV_22_UTS_05
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void gAMESToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox3.BorderStyle = BorderStyle.Fixed3D;
            pictureBox2.BorderStyle = BorderStyle.None;
            pictureBox4.BorderStyle = BorderStyle.None;
            Random rnd = new Random();
            int comp = rnd.Next(0, 3);


            if (comp == 1)
            {
                label1.Text = "Gunting Vs Gunting";
                label2.Text = "Seri";
                listBox1.Items.Add("Seri");
            }
            else if (comp == 2)
            {
                label1.Text = "Gunting Vs Kertas";
                label2.Text = "Kamu Menang";
                progressBar1.PerformStep();
                listBox1.Items.Add("Menang");
                listBox2.Items.Add("Gunting VS Kertas");
            }
            else
            {
                label1.Text = "Gunting Vs Batu";
                label2.Text = "Kamu Kalah";
                listBox1.Items.Add("Kalah");
            }

            if (listBox2.Items.Count == 10)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 10 KALI MAINNYA HEBAT", "NOTIF");
            }
            else if (listBox2.Items.Count == 50)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 50 KALI BELOM BOSEN??????? GAS!!!!!!!!!", "NOTIF");
            }
            else if (listBox2.Items.Count == 100)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 100 KALI STOP GABUTTTTTTT", "NOTIF");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.BorderStyle = BorderStyle.None;
            pictureBox2.BorderStyle = BorderStyle.Fixed3D;
            pictureBox4.BorderStyle = BorderStyle.None;
            Random rnd = new Random();
            int comp = rnd.Next(0, 3);
            

            if (comp == 1)
            {
                label1.Text = "Batu Vs Gunting";
                label2.Text = "Kamu Menang";
                progressBar1.PerformStep();
                listBox1.Items.Add("Menang");
                listBox2.Items.Add("Batu VS Gunting");
            }
            else if (comp == 2)
            {
                label1.Text = "Batu Vs Kertas";
                label2.Text = "Kamu Kalah";
                listBox1.Items.Add("Kalah");
            }
            else
            {
                label1.Text = "Batu Vs Batu";
                label2.Text = "Seri";
                listBox1.Items.Add("Seri");
            }
                
            if(listBox2.Items.Count == 10)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 10 KALI MAINNYA HEBAT", "NOTIF");
            }
            else if(listBox2.Items.Count == 50)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 50 KALI BELOM BOSEN??????? GAS!!!!!!!!!", "NOTIF");
            }else if(listBox2.Items.Count == 100)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 100 KALI STOP GABUTTTTTTT", "NOTIF");
            }
            
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pictureBox4_Click(sender, e, progressBar1);
        }

        private void pictureBox4_Click(object sender, EventArgs e, ProgressBar progressBar1)
        {
            pictureBox3.BorderStyle = BorderStyle.None;
            pictureBox2.BorderStyle = BorderStyle.None;
            pictureBox4.BorderStyle = BorderStyle.Fixed3D;

            Random rnd = new Random();
            int comp = rnd.Next(0, 3);


            if (comp == 1)
            {
                label1.Text = "Kertas Vs Gunting";
                label2.Text = "Kamu Kalah";
                listBox1.Items.Add("Kalah");
            }
            else if (comp == 2)
            {
                label1.Text = "Kertas Vs Kertas";
                label2.Text = "Seri";
                listBox1.Items.Add("Seri");
            }
            else
            {
                label1.Text = "Kertas Vs Batu";
                label2.Text = "Kamu Menang";
                progressBar1.PerformStep();
                listBox1.Items.Add("Menang");
                listBox2.Items.Add("Kertas VS Batu");
            }

            if (listBox2.Items.Count == 10)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 10 KALI MAINNYA HEBAT", "NOTIF");
            }
            else if (listBox2.Items.Count == 50)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 50 KALI BELOM BOSEN??????? GAS!!!!!!!!!", "NOTIF");
            }
            else if (listBox2.Items.Count == 100)
            {
                MessageBox.Show("VV4VV KAMU SUDAH MENANG 100 KALI STOP GABUTTTTTTT", "NOTIF");
                progressBar1.Value = 0;
            }
        }
    }
}
