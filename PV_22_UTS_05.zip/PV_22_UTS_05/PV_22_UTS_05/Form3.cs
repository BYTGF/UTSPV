﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV_22_UTS_05
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Visible = true;
            if(comboBox1.Text == "Easy")
            {
               label1.Text = "Tebak Angka Dari 1 - 10, \nKamu Punya 5 Kesempatan";
                Random rnd = new Random();
                int comp = rnd.Next(1, 11);
                label2.Text = comp.ToString();
                progressBar1.Maximum = 5;
                progressBar1.Value = 0;
            }
            if (comboBox1.Text == "Medium")
            {
                label1.Text = "Tebak Angka Dari 1 - 15, \nKamu Punya 4 Kesempatan";
                Random rnd = new Random();
                int comp = rnd.Next(1, 16);
                label2.Text = comp.ToString();
                progressBar1.Maximum = 4;
                progressBar1.Value = 0;
            }
            if (comboBox1.Text == "Hard")
            {
                label1.Text = "Tebak Angka Dari 1 - 25, \nKamu Punya 3 Kesempatan";
                Random rnd = new Random();
                int comp = rnd.Next(1, 26);
                label2.Text = comp.ToString();
                progressBar1.Maximum = 3;
                progressBar1.Value = 0;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == label2.Text)
            {
                pictureBox1.Visible = true;
                pictureBox2.Visible = false;
                MessageBox.Show("Benar Angkanya : " + label2.Text, "HASIL", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox1.Text != label2.Text)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = true;
                progressBar1.PerformStep();
            }

            if(progressBar1.Value == progressBar1.Maximum)
            {
                button2.Visible=false;
                MessageBox.Show("Kamu Gagal :(((((, Angkanya yang Benar Adalah :" + label2.Text + "\nKlik Tombol Mulai untuk coba Lagi", "HASIL", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {
            
        }
    }
}
